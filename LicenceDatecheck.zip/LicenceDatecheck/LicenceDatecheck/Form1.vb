﻿Public Class Form1
    Function CheckLicenceByValue() As Boolean
        Dim dateval As Integer = Val(Date.Today.Year.ToString() + Date.Today.Month.ToString() + Date.Today.Day.ToString())
        Return dateval < 2020814
    End Function

    Function CompareDate() As Boolean
        Dim mydate As Date = New Date(2020, 8, 14)
        Return Date.Compare(Date.Today, mydate)
    End Function

    Function CompareDateByFormat() As Boolean
        Dim mydate As String = "2020-08-14"
        Dim sysdate As String = Date.Today.ToString("yyyy-MM-dd")
        Return mydate <> sysdate
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbl1.Text += " : " + CheckLicenceByValue().ToString()
        lbl2.Text += " : " + CompareDate().ToString()
        lbl3.Text += " : " + CompareDateByFormat().ToString()
    End Sub

    Private Sub checklicence_Click(sender As Object, e As EventArgs) Handles checklicence.Click
        If CheckLicenceByValue() = False Then
            End
        End If
    End Sub
End Class
